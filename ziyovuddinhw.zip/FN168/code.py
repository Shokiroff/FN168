from flask import Flask
app = Flask(__name__)

<<<<<<< HEAD


=======
@app.route('/')
def func():
	return "<h1> Ulgurdizlarmi <h1>"



if __name__ == "__main__":
	app.run(debug=True)
>>>>>>> e1954cbc21aaed692878f464449533c505187e3f

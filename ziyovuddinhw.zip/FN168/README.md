# FN168
Guruh o'quvchilarga o'rgatish uchun

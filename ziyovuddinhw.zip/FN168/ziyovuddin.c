#include <stdio.h>
int main()
{
printf("salom ustoz tekshirdizmi yahshi chiqibtimi?");
}

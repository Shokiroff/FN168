#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int irand(int x, int y)
{
	return x + rand() % (y - x + 1);
}

int main()
{
system("clear");

int N;

	printf("Massivda nechta element bo'sin >>>");
	scanf("%d",&N);

int arr[N];

printf("\n\n\tArr elementlari:");

for(int i=0; i<N; i++)
{
	arr[i] = irand(10,99);
	printf(" %d",arr[i]);
}

printf("\n\n\t Result:");

for(int i=1; i < N - 1; i++)
{
if(arr[i] > arr[i-1] && arr[i] > arr[i+1])
printf(" %d",arr[i]);
}


printf("\n\n\n");

return 0;
}

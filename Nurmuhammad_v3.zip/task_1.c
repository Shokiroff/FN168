#include<stdio.h>
#include<stdlib.h>

int main()
{
system("clear");

int N,x,sum = 0;

	printf("Soningizni kiriting >>>");
	scanf("%d",&N);

while(N > 0)
{
x = N % 10;
if(x % 2 == 1)
{
sum += x*x;
}
N = N / 10;
}

	printf("\n\n\t##### Result=> %d #####\n\n",sum);
return 0;
}

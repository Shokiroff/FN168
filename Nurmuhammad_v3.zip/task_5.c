#include <stdio.h>

void ildiz(long number, long *root)
{
	while (*root * *root < number)
		*root = *root + 1;
}

int main()
{
system("clear");
	long son,result;
	printf("Enter ur number >>> ");
	scanf("%ld",&son);
	result = 0;
	ildiz(son,&result);
	printf("\n ##### Result => %ld #####\n\n",result);
	return 0;
}

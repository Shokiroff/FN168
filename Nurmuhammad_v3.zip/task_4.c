#include<stdio.h>
#include<stdlib.h>

int main()
{
system("clear");

int mat[5][5];
int mas[25];
int x = 1;
	printf("Enter 25 numbers: \n");
for(int i=0; i<5; i++)
{
for(int j=0; j<5; j++)
{
	printf("%d>",x);
	scanf("%d",&mat[i][j]);
x++;
}
}


for(int i=0; i<5; i++)
{
for(int j=0; j<5; j++)
{
if(j == 0 || i == 4 || i == j || i==2 && j==1 || i==3 && j==1 || i==3 && j==2)
{
mat[i][j] = mat[i][j];
}
else mat[i][j] = 0;

printf(" %3d",mat[i][j]);
}
printf("\n\n");
}
return 0;
}

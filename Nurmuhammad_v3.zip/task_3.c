#include <stdio.h>
#include <stdlib.h>
#include <string.h>

char* function(char *s)
{
	int j = 0;
	int len = strlen(s);
	while (j < len)
	{
		if (s[j] == '+')
		{
			len += 2;
			s = realloc(s, (len + 1) * sizeof(char));
			if (s == NULL)
			{
				printf("### ERROR! ###\n");
				exit(1);
			}
			for (int i = len; i > j; i--)
				s[i] = s[i - 2];
			s[j + 1] = '+';
			s[j + 2] = '+';
			j += 3;
		}
		else j++;
	}
	return s;
}

int main()
{
system("clear");
	char tmp[1000];
	printf("Enter str >>> ");
	scanf("%[^\n]%*c", tmp);
	char *str = malloc(strlen(tmp) + 1);
	if (str == NULL)
	{
		printf("### ERROR! ###\n");
		return 0;
	}
	strcpy(str, tmp);
	str = function(str);
	printf("%s", str);
	free(str);
	return 0;
}

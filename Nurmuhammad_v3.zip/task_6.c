#include<stdio.h>
#include<stdlib.h>
#include<stdbool.h>
#include<string.h>

bool polindrom(char word[],int len)
{

for(int i=0; i<len/2; i++)
{
if(word[i] != word[len-i-1])
return false;
}
return true;
}

int main()
{
system("clear");
char text[300];

	printf("Birinchi fayldagi so'zlarni kiriting >>> ");
	scanf(" %[^\n]%*c",text);

FILE *txt = fopen("Strings.txt","w");
fprintf(txt,"%s",text);

fclose(txt);

txt = fopen("Strings.txt","r");

int len;

char word[100];

FILE *res = fopen("result.txt","w");

while(fscanf(txt,"%s",word) == 1)
{
len = strlen(word);
if(polindrom(word,len) == true)
fprintf(res,"\t%s\n",word);
else fprintf(res,"\t%s - Is not polindrom\n",word);
}

fclose(txt);
fclose(res);

system("start Strings.txt");

system("start result.txt");
return 0;
}


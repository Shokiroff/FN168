#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int palindrommi(char soz[])
	{
    	int boshi = 0;
    	int oxiri = strlen(soz) - 1;
    	while (oxiri > boshi)
	{
        	if (tolower(soz[boshi]) != tolower(soz[oxiri]))
		{
            		return 0;
        	}
        	boshi++;
        	oxiri--;
    	}
    	return 1;
}

int main()
{
	system("clear");
    	char matn[1000];
    	char soz[100];
    	int index = 0;
    	printf("Matn kiriting: ");
    	fgets(matn, sizeof(matn), stdin);
    	FILE *fayl = fopen("6task.txt", "w");
    	if (fayl == NULL)
	{
        	printf("Xatolik!\n");
        	return 1;
    	}

    	printf("\nTopilgan palindrom so'zlar:\n");
    	for (int i = 0; i <= strlen(matn); i++)
	{
        	if (isalpha(matn[i]))
		{
            		soz[index++] = tolower(matn[i]);
        	}
		else
		{
            		soz[index] = '\0';
            		if (strlen(soz) >= 2 && palindrommi(soz))
			{
                		printf("%s\n", soz);
                		fprintf(fayl, "%s\n", soz);
            		}
            		index = 0;
        	}
    	}
    	fclose(fayl);
    	printf("\nfaylga yozildi!\n");
    	return 0;
}

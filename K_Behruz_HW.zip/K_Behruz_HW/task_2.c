#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int irand(int a, int b)
{
	return a + rand() % ( b - a + 1);
}

int main()
{
	system("clear");
	srand(time(NULL));
	int n;
	printf("massiv elementlari = ");
	scanf("%d",&n);
	int a,b;
	printf("ranga qiymat kiriting a dan b gacha(a b) >> ");
	scanf("%d %d",&a,&b);
	int arr[n];

	for(int i = 0; i < n; i++ )
	{
		arr[i]= irand(a,b);
		printf("%d  ",arr[i]);
	}
	int cnt = 0;
	for(int i = 1; i < n - 1; i++)
	{
		if(arr[i]>arr[i-1] && arr[i]>arr[i+1])
		{
			printf("\nindex = %d  ->  %d\n",i,arr[i]);
			cnt++;
		}
	}
	printf("\nlocal max lar soni = %d ta \n",cnt);
}

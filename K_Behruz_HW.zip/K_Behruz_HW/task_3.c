#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void function(char **s_ptr)
{
    	char *s = *s_ptr;
    	int n = strlen(s);
    	int j = 0;

    	while (j < n)
    	{
        	if (s[j] == '+')
        	{
            		n += 2;
            		s = realloc(s, (n + 1) * sizeof(char)); // +1 for '\0'

            		if (!s)
			{
                		printf("xatolik!\n");
                		exit(1);
            		}

            		for (int i = n; i > j; i--)
                	s[i] = s[i - 2];

            		s[j + 1] = '+';
            		s[j + 2] = '+';
            		j += 3;
        	}
        	else
        	{
            		j++;
        	}
    	}
    	s[n] = '\0';
    	*s_ptr = s;
}

int main()
{
    	system("clear");
    	char buffer[1000];
    	printf("Satr kiriting >>> ");
    	scanf(" %[^\n]%*c", buffer);
    	char *str = malloc(strlen(buffer) + 1);
    	strcpy(str, buffer);
    	function(&str);
    	puts(str);
    	free(str);
    	return 0;
}

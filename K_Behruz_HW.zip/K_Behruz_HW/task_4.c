#include <stdio.h>
#include <stdlib.h>

int main()
{
	system("clear");
	int n;
	int cnt = 1;
	printf("massivga qiymat kiriting >> ");
	scanf("%d",&n);
	int arr[n][n];

	for(int i = 0; i < n; i++)
	{
		for(int j = 0; j < n; j++)
		{
			arr[i][j] = cnt++;
			if(j > i)
			arr[i][j] = 0;
			printf("%4d",arr[i][j]);
		}
		printf("\n\n");

	}
	return 0;

}


#include <stdio.h>
#include <stdlib.h>

int main ()
{
	system("clear");
	int N;
	printf("son kiriting >> ");
	scanf("%d",&N);

	int cnt,sum = 0;
	while (N != 0)
	{
	cnt = N % 10;
		if (cnt % 2 == 1)
		{
			sum = sum + (cnt * cnt);
		}
	N = N / 10;
	}
	printf("\ntoq raqamlar kv yigindisi = %d \n",sum);
	return 0;
}
